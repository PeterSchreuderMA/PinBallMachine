# Markdown
In dit document wordt verteld hoe je markdown gebruikt om .md documenten op te maken. Markdown is een populaire opmaak syntax die vaak online gebruikt wordt. Deze wordt onder andere gebruikt door Trello en Github.

[De syntax vind je hier](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet).

Markdown werkt onhandig als je er niet gewend aan bent, Daarom raad ik het aan om gebruik te maken van een Atom of Visual Studio Code plugin waarbij je de markdown preview makkelijk kan lezen.
